const fs = require('fs');
const path = require('path');
const {createCanvas,loadImage,GlobalFonts} = require('/workspace/psd-tooling/node_modules/@napi-rs/canvas');
const ag = require('/workspace/psd-tooling/node_modules/ag-psd');
ag.initializeCanvas(createCanvas);
GlobalFonts.registerFromPath('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc','PosterSans');
GlobalFonts.registerFromPath('/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc','PosterSerif');
GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','PosterLatin');
const root=__dirname,W=717,H=1085;
const blank=()=>createCanvas(W,H);
const data=c=>c.getContext('2d').getImageData(0,0,W,H);
const stack=[];
const flat=[];
async function png(name,file){
 const c=blank();c.getContext('2d').drawImage(await loadImage(path.join(root,'assets',file)),0,0,W,H);
 return {name,imageData:data(c)};
}
function addGroup(name,children){stack.push({name,opened:true,children});flat.push(...children);}
function shape(name,points,color,stroke){
 const c=blank(),ctx=c.getContext('2d');ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();
 ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.5;ctx.stroke();}
 const rgb={r:parseInt(color.slice(1,3),16),g:parseInt(color.slice(3,5),16),b:parseInt(color.slice(5,7),16)};
 return {name,imageData:data(c),vectorFill:{type:'color',color:rgb},vectorMask:{paths:[{open:false,operation:'combine',fillRule:'non-zero',knots:points.map(([x,y])=>({linked:true,points:[x,y,x,y,x,y]}))}]}};
}
function text(name,value,opts){
 const {x,y,size,width,family='PosterSans',psfont='NotoSansCJKsc-Bold',skew=0,stroke=0}=opts;
 const fontSpec=`${family==='PosterSans'?'700':'400'} ${size}px "${family}"`;
 const c=blank(),ctx=c.getContext('2d');ctx.font=fontSpec;
 const sx=width?width/ctx.measureText(value).width:1;
 ctx.setTransform(sx,0,skew,1,x,y);ctx.font=fontSpec;ctx.fillStyle='#ffffff';
 if(stroke){ctx.strokeStyle='#e51b23';ctx.lineWidth=stroke;ctx.lineJoin='miter';ctx.strokeText(value,0,0);}
 ctx.fillText(value,0,0);
 const style={font:{name:psfont},fontSize:size,fillColor:{r:255,g:255,b:255},fillFlag:true,strokeFlag:!!stroke,strokeColor:{r:229,g:27,b:35},outlineWidth:stroke/2,fillFirst:false};
 return {name,imageData:data(c),text:{text:value,transform:[sx,0,skew,1,x,y],antiAlias:'smooth',orientation:'horizontal',shapeType:'point',style,paragraphStyle:{justification:'left'}}};
}
async function main(){
 addGroup('01 背景与舞台光 · 生成重建',[await png('深色星尘 / 光束 / 几何框','background.png')]);
 addGroup('03 金色数字 · 生成重建',[
  await png('扩散投影 · 待人工校准','gold-soft.png'),await png('接触实影 · 待人工校准','gold-contact.png'),await png('金色 11.11 装饰','gold.png')]);
 addGroup('02 红色展台 · 生成重建',[await png('展台组合 · 可独立移动','pedestals.png')]);
 for(const [id,label] of [['main','中央集成灶'],['left','左侧烤箱'],['right','右侧烤箱']]){
  const layers=id==='main'?[]:[await png('扩散投影 · '+label,id+'-soft.png'),await png('接触实影 · '+label,id+'-contact.png')];
  layers.push(await png(label,id+'.png'));
  addGroup('04 '+label+' · 生成重建',layers);
 }
 addGroup('05 前景猫形装饰',[await png('扩散投影 · 猫形装饰','cat-soft.png'),await png('接触实影 · 猫形装饰','cat-contact.png'),await png('猫形装饰','cat.png')]);
 addGroup('06 飘浮红包与纸屑',[await png('左上红包','envelope-top.png'),await png('右侧红包','envelope-right.png'),await png('左下红包','envelope-left.png'),await png('左侧纸屑','paper-left.png'),await png('右侧纸屑','paper-right.png'),await png('其他微小装饰','decor-other.png')]);
 addGroup('07 促销横幅 · 原生形状',[
  shape('横幅外框',[[61,377],[677,377],[656,450],[40,450]],'#490609','#e51b23'),
  shape('横幅主体',[[68,385],[666,385],[647,442],[48,442]],'#900308','#ff2222')]);
 addGroup('08 文案 · 原生可编辑文字 / 替代字体',[
  text('主标题 · 双11狂欢热浪','双11狂欢热浪',{x:84,y:198,size:94,width:520,skew:-.2,stroke:3}),
  text('副标题 · 燃爆全场','燃爆全场',{x:128,y:334,size:112,width:439,skew:-.2,stroke:3}),
  text('促销说明','- 抢前20名付尾款 送500元惊喜红包 -',{x:87,y:426,size:33,width:543,family:'PosterSerif',psfont:'NotoSerifCJKsc-Regular',skew:-.1}),
  text('天猫双11 · 字体替代','天猫双11',{x:174,y:73,size:32,width:133}),
  text('品牌文字占位 · 请换官方标志','DP depelec',{x:337,y:73,size:35,width:210,family:'PosterLatin',psfont:'DejaVuSans'}),
 ]);
 addGroup('09 顶部品牌分隔线',[shape('分隔线',[[320,47],[321,47],[321,76],[320,76]],'#cccccc')]);
 const composite=blank(),ctx=composite.getContext('2d');
 for(const l of flat){const c=blank();c.getContext('2d').putImageData(l.imageData,0,0);ctx.drawImage(c,0,0);}
 const psd={width:W,height:H,children:stack,imageData:data(composite),imageResources:{resolutionInfo:{horizontalResolution:72,verticalResolution:72,horizontalResolutionUnit:'PPI',verticalResolutionUnit:'PPI',widthUnit:'Inches',heightUnit:'Inches'}}};
 const buffer=ag.writePsdBuffer(psd,{generateThumbnail:false,invalidateTextLayers:false});
 fs.writeFileSync(path.join(root,'双11海报_分层重建草稿.psd'),buffer);
 fs.writeFileSync(path.join(root,'预览.png'),composite.toBuffer('image/png'));
 const reopened=ag.readPsd(buffer,{skipLayerImageData:true,skipCompositeImageData:true,skipThumbnail:true});
 const layers=reopened.children.flatMap(g=>g.children||[]);
 const report={canvas:[W,H],groups:reopened.children.length,contentLayers:layers.length,textLayers:layers.filter(l=>l.text).map(l=>({name:l.name,text:l.text.text})),vectorLayers:layers.filter(l=>l.vectorMask).length,pixelLayers:layers.filter(l=>!l.text&&!l.vectorMask).length,validation:{agPsdReadback:'PASS',photoshopReopen:'NOT RUN - Photoshop unavailable',visualIdentity:'RECONSTRUCTION DRAFT - differs from source',smartObjects:'NOT IMPLEMENTED - raster image layers'}};
 fs.writeFileSync(path.join(root,'structure-report.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report,null,2));
}
main().catch(e=>{console.error(e);process.exit(1)});
