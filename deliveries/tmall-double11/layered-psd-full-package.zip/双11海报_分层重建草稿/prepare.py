"""Prepare only newly generated transparent assets; never segment source photo."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
sys.path.insert(0,'/workspace/-/.agents/skills/image-to-layered-psd/scripts')
from asset_ops import inspect_alpha,shadow

ROOT=Path(__file__).parent
OUT=ROOT/'assets';OUT.mkdir(exist_ok=True)
W,H=717,1085
G=Path('/workspace/generated_images')
sources=json.loads((ROOT/'sources.json').read_text())
report={}
def load(key):
 p=G/sources[key]
 im=Image.open(p).convert('RGBA')
 original=im.size
 im=im.convert('RGBa').resize((W,H),Image.Resampling.LANCZOS).convert('RGBA')
 report[key]={'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'generatedSize':original,'normalizedSize':[W,H]}
 return im
def save(im,name):
 im.save(OUT/(name+'.png'))
 report.setdefault(name,{}).update(alpha=inspect_alpha(im))
def transform(im,s=1,dx=0,dy=0):
 # Uniform similarity only, evaluated with premultiplied RGB to avoid dark rims.
 result=im.convert('RGBa').transform((W,H),Image.Transform.AFFINE,(1/s,0,-dx/s,0,1/s,-dy/s),Image.Resampling.BICUBIC).convert('RGBA')
 return result
def separate(im,regions):
 a=np.asarray(im).copy(); assigned=np.zeros((H,W),bool);result={}
 for name,(x0,y0,x1,y1) in regions.items():
  mask=np.zeros((H,W),bool);mask[y0:y1,x0:x1]=True
  assert not np.any(mask&assigned)
  piece=np.zeros_like(a);piece[mask]=a[mask];result[name]=Image.fromarray(piece);assigned|=mask
 rest=np.zeros_like(a);rest[~assigned]=a[~assigned]
 result['other']=Image.fromarray(rest)
 # Assert exact RGBA conservation before per-element registration.
 total=np.zeros_like(a,dtype=np.uint16)
 for im in result.values():total+=np.asarray(im).astype(np.uint16)
 assert np.array_equal(total,a)
 return result
def shadows(name,im,miny):
 for kind,dx,dy,back,front,blur,opacity in [('contact',.4,.6,1,1,1.2,.55),('soft',8,5,2,3,7,.23)]:
  result=shadow(im,'base',dx,dy,back,front,miny)
  alpha=result.getchannel('A').filter(ImageFilter.GaussianBlur(blur)).point(lambda v:round(v*opacity))
  result.putalpha(alpha);save(result,name+'-'+kind)

bg=load('background');bg.convert('RGB').save(OUT/'background.png')
save(transform(load('pedestals'),dx=0,dy=46),'pedestals')
gold=transform(load('gold'),s=.87,dx=69,dy=53);save(gold,'gold');shadows('gold',gold,800)
main=transform(load('main'),s=.72,dx=88,dy=163);save(main,'main')
sides=load('sides')
pieces=separate(sides,{'left':(0,0,358,H),'right':(358,0,W,H)})
assert np.asarray(pieces['other'].getchannel('A')).sum()==0
for name,s,dx,dy,miny in [('left',.9,.6,106,800),('right',.85,106,104,775)]:
 im=transform(pieces[name],s=s,dx=dx,dy=dy);save(im,name);shadows(name,im,miny)
deco=load('decor')
regions={'cat':(200,820,550,H),'envelope-top':(0,0,180,320),'envelope-right':(570,330,W,700),'envelope-left':(0,640,160,780),'paper-left':(0,430,180,640),'paper-right':(570,700,W,850)}
parts=separate(deco,regions)
for name,im in parts.items():
 name='decor-other' if name=='other' else name
 if name=='cat':im=transform(im,dx=44,dy=30)
 save(im,name)
 if name=='cat':shadows(name,im,1000)
report['registration']={'main':[[.72,0,88],[0,.72,163]],'left':[[.9,0,.6],[0,.9,106]],'right':[[.85,0,106],[0,.85,104]],'gold':[[.87,0,69],[0,.87,53]],'cat':[[1,0,44],[0,1,30]],'pedestals':[[1,0,0],[0,1,46]],'basis':'Approximate manual registration against visible source hood/base anchors, gold upper tips, pedestal top and cat eye position; similarity transforms only; final visual QA remains draft.'}
report['limitations']=['Generated rather than extracted source objects','Hidden structure inferred','No Photoshop verification','Raster image layers; no embedded smart objects','Source inline image not embedded as hidden reference','Background frame and spotlights remain in one raster layer','Original brand marks and exact headline font unavailable','Fine edge-color QA and native-filter QA incomplete']
(ROOT/'asset-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Prepared',len(list(OUT.glob('*.png'))),'full-canvas PNG assets; alpha conservation before registration PASS')
